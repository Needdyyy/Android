package com.needyyy.app.Modules.Home.Activities;

import android.app.AlertDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.internal.BottomNavigationItemView;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.needyyy.AppController;
import com.needyyy.app.Base.BaseActivity;
import com.needyyy.app.Base.CommonPojo;
import com.needyyy.app.Chat.Adapter.ChatAdapter;
import com.needyyy.app.Chat.chatDialogActivity;
import com.needyyy.app.Chat.common.ChatPojo;
import com.needyyy.app.Chat.groupchatwebrtc.activities.OpponentsActivity;
import com.needyyy.app.ImageClasses.ZoomImage.ZoomImage;
import com.needyyy.app.Modules.AddPost.Fragments.PostFragment;
import com.needyyy.app.Modules.AddPost.models.PeopleBase;
import com.needyyy.app.Modules.Dating.FilterFragment;
import com.needyyy.app.Modules.Dating.FriendSuggestion;
import com.needyyy.app.Modules.Dating.suggestions.fragment.SendRequestFragment;
import com.needyyy.app.Modules.Home.Fragments.ContactUsFragment;
import com.needyyy.app.Modules.Home.Fragments.HomeFragment;
import com.needyyy.app.Modules.Home.Fragments.NotificationFragment;
import com.needyyy.app.Modules.Home.Fragments.SearchFriendFragment;
import com.needyyy.app.Modules.Home.Fragments.SecurityFragment;
import com.needyyy.app.Modules.Home.Fragments.ViewFullImageFragment;
import com.needyyy.app.Modules.Home.Fragments.WalletFragment;
import com.needyyy.app.Modules.Home.modle.CommentBase;
import com.needyyy.app.Modules.Home.modle.CommentData;
import com.needyyy.app.Modules.Home.modle.PostResponse;
import com.needyyy.app.Modules.Knocks.fragment.KnocksFragment;
import com.needyyy.app.Modules.Login.Activities.LoginActivity;
import com.needyyy.app.Modules.Login.model.register.UserDataResult;
import com.needyyy.app.Modules.Profile.fragments.FriendsListFragment;
import com.needyyy.app.Modules.Profile.fragments.SeeAllPhotoFragment;
import com.needyyy.app.Modules.Profile.fragments.ViewProfileFragment;
import com.needyyy.app.Modules.adsAndPage.adapter.MyGlobalPostAdapter;
import com.needyyy.app.Modules.adsAndPage.fragment.AdsManagerFragment;
import com.needyyy.app.Modules.adsAndPage.fragment.BookmarkFragment;
import com.needyyy.app.Modules.adsAndPage.fragment.GlobalPostFragment;
import com.needyyy.app.Modules.adsAndPage.fragment.MyPageFragment;
import com.needyyy.app.Modules.adsAndPage.modle.MyPage;
import com.needyyy.app.Modules.adsAndPage.modle.PageData;
import com.needyyy.app.Modules.adsAndPage.modle.wallet.modle.GlobalPost;
import com.needyyy.app.R;
import com.needyyy.app.manager.BaseManager.BaseManager;
import com.needyyy.app.mypage.model.Activities.Data;
import com.needyyy.app.mypage.model.Activities.Getpostdata;
import com.needyyy.app.mypage.mypage_details;
import com.needyyy.app.utils.BottomNavigationViewBehavior;
import com.needyyy.app.utils.BottomNavigationViewHelper;
import com.needyyy.app.utils.CommonUtil;
import com.needyyy.app.utils.Constant;
import com.needyyy.app.views.GridSpacingItemDecoration;
import com.needyyy.app.webutils.WebInterface;
import com.razorpay.PaymentResultListener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import static com.needyyy.app.Modules.adsAndPage.fragment.GlobalPostFragment.tv_writesomething;
import static com.needyyy.app.constants.Constants.kCurrentUser;

public class HomeActivity extends BaseActivity
        implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener , PaymentResultListener {
    private String idd="";
    public PostResponse postresponse;
    public MyPage myPage;
    ArrayList<Getpostdata> getPostData = new ArrayList<>();
    public static final int TAG_USER = 2929;
    public static final int DIALOG_FRAGMENT = 1;
    private File destFile;
    private File file;
    private File sourceFile;
    public static FragmentManager manager;
    private SimpleDateFormat dateFormatter;
    public static final String DATE_FORMAT = "yyyyMMdd_HHmmss";
    private static final String TAG = "HomeActivity";
    public CircleImageView imgProfile;
    public Fragment fragment;
    public BottomNavigationView navigation,navigation1;
    private UserDataResult userData ;
    public BottomNavigationItemView nvHome, nvPost, nvKnocks, nvProfile;
    private View SocialView, DiatView;
    private LinearLayout llSocial, llDating;
    Button toolbar_post;
    private SearchView toolbarSearch ;
    private String memberId,type,taskid;
    private Boolean isSocial=true;
    private DatabaseReference mFirebaseDatabaseReference;
    private TextView toolbarTitle,tvSocial,tvUserName, tvDating, tvHomeSocial, tvChatgroupSocial, tvBookmarkSocial,tv_global_post, tvNearfriendSocial, tvAddmanagerSocial, tvMypageSocial, tvWalletSocial, tvAboutusSocial, tvSecuritySocial, tvHelpsupportSocial, tvLogoutSocial, tvHomeDaiting, tvAboutusDaiting, tvSecurityDaiting, tvHelpsupportDaiting, tvLogoutDaiting;
    private ImageView ivSocial, ivDating,toolbarMenu,toolbarBack,toolbarChat,toolbarVideoCall,toolbarNotification,toolbarFilter,coverpic;
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.nv_home:
                    tvHomeSocial.setBackgroundColor(getResources().getColor(R.color.color_gray_bg));
                    tvChatgroupSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvBookmarkSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tv_global_post.setBackgroundColor(getResources().getColor(R.color.white));
                    tvNearfriendSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvAddmanagerSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvMypageSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvWalletSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvAboutusSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvSecuritySocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvHelpsupportSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    popAllStack();
                    replaceFragment(HomeFragment.newInstance(), false);
                    return true;
                case R.id.nv_post:

                    tvHomeSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvChatgroupSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvBookmarkSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvNearfriendSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvAddmanagerSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvMypageSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvWalletSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvAboutusSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvSecuritySocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvHelpsupportSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    replaceFragment(PostFragment.newInstance(null), true);
                    return true;
                case R.id.nv_knocks:

                    tvHomeSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvChatgroupSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvBookmarkSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvNearfriendSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvAddmanagerSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvMypageSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvWalletSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvAboutusSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvSecuritySocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvHelpsupportSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    replaceFragment(KnocksFragment.newInstance(), true);
                    return true;
                case R.id.nv_profile:

                    tvHomeSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvChatgroupSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvBookmarkSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvNearfriendSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvAddmanagerSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvMypageSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvWalletSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvAboutusSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvSecuritySocial.setBackgroundColor(getResources().getColor(R.color.white));
                    tvHelpsupportSocial.setBackgroundColor(getResources().getColor(R.color.white));
                    replaceFragment(ViewProfileFragment.newInstance(userData.getId(),null),true);
                    return true;
                case R.id.nv_suggestion:
                    replaceFragment(FriendSuggestion.newInstance(), true);
                    return true;
                case R.id.nv_myfriend:
                    replaceFragment(FriendsListFragment.newInstance(1), true);
                    return true;
                case R.id.nv_profile_dating:
                    replaceFragment(ViewProfileFragment.newInstance(userData.getId(),null), true);
                    return true;
                case R.id.nv_knocks_dating:
                    replaceFragment(KnocksFragment.newInstance(), true);
                    return true;
            }
            return false;
        }
    };

    private boolean closeApp = false;

    public static Intent getIntent(Context context) {
        return new Intent(context, HomeActivity.class);
    }

    @Override
    protected void onStop() {
        super.onStop();

    }

    @Override
    protected void onResume() {
        super.onResume();

    }

//    private void fireBaseOperation() {
////        mFirebaseDatabaseReference = FirebaseDatabase.getInstance().getReference().child(SharedPreference.getInstance().getLoggedInUser().getId());
//        mFirebaseDatabaseReference = FirebaseDatabase.getInstance().getReference().child("needyyy/users/"+userData.getId());
////        mFirebaseDatabaseReferenceName = FirebaseDatabase.getInstance().getReference().child("user").child(SharedPreference.getInstance().getLoggedInUser().getId());
//
//        ivSend.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                // chatHit();
//                Calendar c = Calendar.getInstance();
//                SimpleDateFormat dateformat = new SimpleDateFormat("MMM dd, yyyy");
//                String datetime = dateformat.format(c.getTime());
//                String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
//
//                if (!etMessage.getText().toString().equals("")) {
//                    ChatPojo message = new ChatPojo(userData.getId(), etMessage.getText().toString(),userData.getName(),datetime,"1",userData.getProfilePicture(),"message","",currentTime,"1");
//                    mFirebaseDatabaseReference.push().setValue(message);
//                    etMessage.setText("");
//                } else {
////                    Helper.showSnackBar(ivSend, "Please enter your query first.");
//                }
//            }
//        });
//
//        arrChat.clear();
//        chatAdapter = new ChatAdapter(this, arrChat);
//        recyclerChat.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
//        recyclerChat.setAdapter(chatAdapter);
//
//        mFirebaseDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot snapshot) {
//                if (snapshot.getValue() != null) {
//                    //user exists, do something
//                } else {
//
//                    Log.d(TAG, "onDataChange: ");
//                    //user does not exist, do something else
//                }
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//
//            }
//
//        });
//
//        mFirebaseDatabaseReference.addChildEventListener(new ChildEventListener() {
//            @Override
//            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
//
//                ChatPojo message = dataSnapshot.getValue(ChatPojo.class);
//                Log.d(TAG, "onChildAdded: "+message.getId());
//                arrChat.add(message);
//                chatAdapter.notifyDataSetChanged();
//                recyclerChat.smoothScrollToPosition(arrChat.size() - 1);
//
//            }
//
//
//            @Override
//            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
//                Log.d(TAG, "onChildChanged: ");
//
//            }
//
//            @Override
//            public void onChildRemoved(DataSnapshot dataSnapshot) {
//                Log.d(TAG, "onChildRemoved: ");
//            }
//
//            @Override
//            public void onChildMoved(DataSnapshot dataSnapshot, String s) {
//                Log.d(TAG, "onChildMoved: ");
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//
//            }
//        });
//
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        if (getIntent().hasExtra(Constant.PUSH_TYPE)) {
            type = getIntent().getStringExtra(Constant.PUSH_TYPE);
            taskid = getIntent().getStringExtra("taskid");
            if(type.equals("22")||type.equals("24")||type.equals("21")||type.equals("24"))
            {
                getpostdata(taskid);

            }
            else if(type.equals("27")||type.equals("1")||type.equals("3"))
            {
                replaceFragment(HomeFragment.newInstance(),true);
            }
           else if(type.equals("2"))
            {
                logout();
            }
            else if(type.equals("5")||type.equals("20"))
            {
                replaceFragment(new com.needyyy.app.notifications.NotificationFragment(), true);
            }
            else if(type.equals("25")||type.equals("26")||type.equals("27")||type.equals("28")||type.equals("29"))
            {
                replaceFragment(mypage_details.newInstance(taskid),true);
              //  getpagedata(taskid);
            }
            else if(type.equals("50")||type.equals("51"))
            {
                replaceFragment(ViewProfileFragment.newInstance(taskid,null), true);
            }
        } else {
            addFragment(HomeFragment.newInstance());
        }
        userData = (BaseManager.getDataFromPreferences(kCurrentUser, UserDataResult.class));
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        navigation = (BottomNavigationView) findViewById(R.id.navigation);
        BottomNavigationViewHelper.removeShiftMode(navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        navigation1 = (BottomNavigationView) findViewById(R.id.navigation1);
        BottomNavigationViewHelper.removeShiftMode(navigation1);
        navigation1.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams) navigation.getLayoutParams();
        layoutParams.setBehavior(new BottomNavigationViewBehavior());

        CoordinatorLayout.LayoutParams layoutParams1 = (CoordinatorLayout.LayoutParams) navigation1.getLayoutParams();
        layoutParams1.setBehavior(new BottomNavigationViewBehavior());

        setReference();
        setListner();
        initSearchView();
        if (userData!=null){
            tvUserName.setText(userData.getName());
            if (!TextUtils.isEmpty(userData.getProfilePicture())) {
                Glide.with(this)
                        .load(userData.getProfilePicture())
                        .into(imgProfile);
            } else {
                imgProfile.setImageResource(R.drawable.needyy);
            }
            if (!TextUtils.isEmpty(userData.getCoverpicture())) {
                Glide.with(this)
                        .load(userData.getCoverpicture())
                        .into(coverpic);
            }
        }
    }
    public void closeToolbarSearch(){

        if (toolbarSearch!= null)
            if (!toolbarSearch.isIconified()) {
                toolbarSearch.setIconified(true);
                toolbarSearch.onActionViewCollapsed();
                AppController.getManager().setSearchQuery("");
            }

    }
    private void initSearchView() {

        toolbarSearch.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                fragment = getSupportFragmentManager().findFragmentById(R.id.frame_main);
                if (fragment instanceof SearchFriendFragment)
                    getActiveFragment();
                toolbarChat.setVisibility(View.VISIBLE);
                toolbarNotification.setVisibility(View.VISIBLE);
                AppController.getManager().setSearchQuery("");
                return false;
            }
        });

        toolbarSearch.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toolbarSearch.setFocusable(true);
                fragment = getSupportFragmentManager().findFragmentById(R.id.frame_main);
                if (fragment instanceof HomeFragment)
                    replaceFragment(SearchFriendFragment.newInstance(), true);

            }
        });

        View searchPlateView = toolbarSearch.findViewById(android.support.v7.appcompat.R.id.search_plate);
        searchPlateView.setBackgroundColor(ContextCompat.getColor(this, android.R.color.transparent

        ));
        // use this method for search process
        toolbarSearch.setQueryHint(getResources().getString(R.string.search_here));
        toolbarSearch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                AppController.getManager().setSearchQuery(query);
                // use this method when query submitted
                fragment = getSupportFragmentManager().findFragmentById(R.id.frame_main);
                SearchDataonFragment(fragment, 0);
                CommonUtil.closeKeyboard(HomeActivity.this);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                AppController.getManager().setSearchQuery(newText);
                return false;
            }
        });
        SearchManager searchManager = (SearchManager) getSystemService(SEARCH_SERVICE);
        toolbarSearch.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
    }

    private void SearchDataonFragment(Fragment fragment, int i) {
        if (fragment instanceof SearchFriendFragment){
            ((SearchFriendFragment) fragment).isRefresh = true;
            ((SearchFriendFragment) fragment).last_post_id = "";
            ((SearchFriendFragment) fragment).firstVisibleItem = 0;
            ((SearchFriendFragment) fragment).previousTotalItemCount = 0;
            ((SearchFriendFragment) fragment).visibleItemCount = 0;

            ((SearchFriendFragment) fragment).RefreshFeedList(true);
        }
    }

    private void setListner() {
        toolbarVideoCall.setOnClickListener(this);
        tvUserName.setOnClickListener(this);
        imgProfile.setOnClickListener(this);
        llSocial.setOnClickListener(this);
        llDating.setOnClickListener(this);
        tvHomeSocial.setOnClickListener(this);
        tvChatgroupSocial.setOnClickListener(this);
        tvBookmarkSocial.setOnClickListener(this);
        tv_global_post.setOnClickListener(this);
        tvNearfriendSocial.setOnClickListener(this);
        tvAddmanagerSocial.setOnClickListener(this);
        tvMypageSocial.setOnClickListener(this);
        tvWalletSocial.setOnClickListener(this);
        tvAboutusSocial.setOnClickListener(this);
        tvSecuritySocial.setOnClickListener(this);
        tvHelpsupportSocial.setOnClickListener(this);
        tvLogoutSocial.setOnClickListener(this);
        tvHomeDaiting.setOnClickListener(this);
        tvAboutusDaiting.setOnClickListener(this);
        tvSecurityDaiting.setOnClickListener(this);
        tvHelpsupportDaiting.setOnClickListener(this);
        tvLogoutDaiting.setOnClickListener(this);
        toolbarBack.setOnClickListener(this);
        toolbarMenu.setOnClickListener(this);
        toolbarSearch.setOnClickListener(this);
        toolbarChat.setOnClickListener(this);
        toolbarNotification.setOnClickListener(this);
        toolbarFilter.setOnClickListener(this);
        toolbar_post.setOnClickListener(this);
    }

    private void setReference() {
        toolbarVideoCall=findViewById(R.id.video_call);
        toolbar_post             = findViewById(R.id.toolbar_post);
        SocialView           = findViewById(R.id.layout_social);
        tvUserName           = findViewById(R.id.tv_username);
        DiatView             = findViewById(R.id.layout_daiting);
        llSocial             = findViewById(R.id.ll_social);
        llDating             = findViewById(R.id.ll_daiting);
        tvSocial             = findViewById(R.id.tv_social);
        tvDating             = findViewById(R.id.tv_daiting);
        ivSocial             = findViewById(R.id.img_social);
        ivDating             = findViewById(R.id.img_daiting);
        tvHomeSocial         = findViewById(R.id.tv_home_social);
        tvChatgroupSocial    = findViewById(R.id.tv_chatgroup_social);
        tvBookmarkSocial     = findViewById(R.id.tv_bookmark_social);
        tv_global_post     = findViewById(R.id.tv_global_post);
        tvNearfriendSocial   = findViewById(R.id.tv_nearfriend_social);
        tvAddmanagerSocial   = findViewById(R.id.tv_addmanager_social);
        tvMypageSocial       = findViewById(R.id.tv_mypage_social);
        tvWalletSocial       = findViewById(R.id.tv_wallet_social);
        tvAboutusSocial      = findViewById(R.id.tv_aboutus_social);
        tvSecuritySocial     = findViewById(R.id.tv_Security_social);
        tvHelpsupportSocial  = findViewById(R.id.tv_helpsupport_social);
        tvLogoutSocial       = findViewById(R.id.tv_logout_social);
        tvHomeDaiting        = findViewById(R.id.tv_home_daiting);
        tvAboutusDaiting     = findViewById(R.id.tv_aboutus_daiting);
        tvSecurityDaiting    = findViewById(R.id.tv_Security_daiting);
        tvHelpsupportDaiting = findViewById(R.id.tv_helpsupport_daiting);
        tvLogoutDaiting      = findViewById(R.id.tv_logout_daiting);
        nvHome               = findViewById(R.id.nv_home);
        nvPost               = findViewById(R.id.nv_post);
        nvKnocks             = findViewById(R.id.nv_knocks);
        nvProfile            = findViewById(R.id.nv_profile);
        toolbarTitle         = findViewById(R.id.toolbar_title);
        toolbarBack          = findViewById(R.id.toolbar_back);
        toolbarMenu          = findViewById(R.id.toolbar_menu);
        toolbarSearch        = findViewById(R.id.toolbar_search);
        toolbarChat          = findViewById(R.id.toolbar_chat);
        toolbarFilter        = findViewById(R.id.toolbar_filter);
        toolbarNotification  = findViewById(R.id.toolbar_notification);
        imgProfile           = findViewById(R.id.civ_profile_pic);
        coverpic             =findViewById(R.id.cover_photo);
    }

    public void  manageToolbar(String title, String memberId){
        this.memberId = memberId;
        toolbarTitle.setText(title);
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.frame_main);
        if (!(fragment instanceof SearchFriendFragment))
            closeToolbarSearch();
        if (fragment instanceof HomeFragment
                || fragment instanceof PostFragment
                || fragment instanceof KnocksFragment){
            toolbarMenu.setVisibility(View.VISIBLE);
            toolbarVideoCall.setVisibility(View.VISIBLE);
            toolbarBack.setVisibility(View.GONE);
            navigation.setVisibility(View.VISIBLE);
            toolbarFilter.setVisibility(View.GONE);
            toolbar_post.setVisibility(View.GONE);
            toolbarNotification.setVisibility(View.VISIBLE);
            toolbarSearch.setVisibility(View.VISIBLE);
            toolbarChat.setVisibility(View.VISIBLE);
        }

        else if(fragment instanceof ViewProfileFragment
                || fragment instanceof com.needyyy.app.notifications.NotificationFragment
                || fragment instanceof mypage_details
                ||fragment instanceof SeeAllPhotoFragment
                ||fragment instanceof SendRequestFragment
                ||fragment instanceof ZoomImage
                ||fragment instanceof ViewProfileFragment
                ){
            toolbar_post.setVisibility(View.GONE);
            toolbarFilter.setVisibility(View.GONE);
            if (!userData.getId().equals(memberId)){
                toolbar_post.setVisibility(View.GONE);
                toolbarMenu.setVisibility(View.GONE);
                toolbarBack.setVisibility(View.VISIBLE);
                navigation.setVisibility(View.GONE);
            }else{
                toolbar_post.setVisibility(View.GONE);
                toolbarMenu.setVisibility(View.VISIBLE);
                toolbarBack.setVisibility(View.GONE);
                navigation.setVisibility(View.VISIBLE);


            }
        }else if((fragment instanceof FriendsListFragment || fragment instanceof  FriendSuggestion )&& isSocial==false){
            toolbarMenu.setVisibility(View.VISIBLE);
            toolbarBack.setVisibility(View.GONE);
            toolbar_post.setVisibility(View.GONE);
            navigation.setVisibility(View.VISIBLE);
            toolbarFilter.setVisibility(View.VISIBLE);
         }
        else if(fragment instanceof GlobalPostFragment) {
            toolbarVideoCall.setVisibility(View.VISIBLE);
            toolbar_post.setVisibility(View.VISIBLE);
            toolbarMenu.setVisibility(View.GONE);
            toolbarBack.setVisibility(View.VISIBLE);
            toolbarNotification.setVisibility(View.GONE);
            toolbarSearch.setVisibility(View.GONE);
            toolbarChat.setVisibility(View.GONE);
        }
         else{
            toolbarMenu.setVisibility(View.GONE);
            toolbarBack.setVisibility(View.VISIBLE);
            toolbar_post.setVisibility(View.GONE);
            navigation.setVisibility(View.GONE);
            toolbarFilter.setVisibility(View.GONE);
        }

        manageBottomnavigation(fragment);
    }

    private void manageBottomnavigation(Fragment fragment) {
        if (fragment instanceof HomeFragment){
            navigation.getMenu().getItem(0).setChecked(true);
        }else if   (fragment instanceof PostFragment){
            navigation.getMenu().getItem(1).setChecked(true);
        }else    if (fragment instanceof KnocksFragment){
            navigation.getMenu().getItem(2).setChecked(true);
        }else    if (fragment instanceof ViewProfileFragment){
            navigation.getMenu().getItem(3).setChecked(true);
        }
    }
    public void snackBar(String message) {
        Snackbar snackbar = Snackbar.make(this.findViewById(R.id.frame_main), message, 10000);
        View mView = snackbar.getView();
        TextView mTextView = (TextView) mView.findViewById(android.support.design.R.id.snackbar_text);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1)
            mTextView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        else
            mTextView.setGravity(Gravity.CENTER_HORIZONTAL);

        snackbar.show();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.frame_main);
        closeToolbarSearch();
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else if (fragment instanceof HomeFragment
                || fragment instanceof PostFragment
                || fragment instanceof KnocksFragment) {
            if (closeApp) {
                finish();
                super.onBackPressed();
            } else {
                CommonUtil.showLongToast(HomeActivity.this, "Press back button again to exit ");
                new CountDownTimer(5000, 500) {
                    public void onTick(long millisUntilFinished) {
                        closeApp = true;
                    }

                    public void onFinish() {
                        closeApp = false;
                    }
                }.start();
            }

        }else if (fragment instanceof FriendSuggestion
                || fragment instanceof FriendsListFragment
                && isSocial == false) {
            if (closeApp) {
                finish();
                super.onBackPressed();
            } else {
                CommonUtil.showLongToast(HomeActivity.this, "Press back button again to exit ");
                new CountDownTimer(5000, 500) {
                    public void onTick(long millisUntilFinished) {
                        closeApp = true;
                    }

                    public void onFinish() {
                        closeApp = false;
                    }
                }.start();
            }

        }else if (fragment instanceof ViewProfileFragment) {
            if (!userData.getId().equals(memberId)) {
                super.onBackPressed();
            } else {
                if (closeApp) {
                    finish();
                    super.onBackPressed();
                } else {
                    CommonUtil.showLongToast(HomeActivity.this, "Press back button again to exit ");
                    new CountDownTimer(5000, 500) {
                        public void onTick(long millisUntilFinished) {
                            closeApp = true;
                        }

                        public void onFinish() {
                            closeApp = false;
                        }
                    }.start();
                }
            }

        } else if (fragment instanceof ViewProfileFragment)
        {
            replaceFragment(HomeFragment.newInstance(), true);
        }else {
            getActiveFragment();
        }
    }


    public void getActiveFragment() {

        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.frame_main);

//        if(fragment instanceof PaymentActivity)
//            ((PaymentActivity) fragment).removeCheckOutItems();
//        if(fragment instanceof ForeignInvestmentListFragment ||fragment instanceof CommunicationListFragment|fragment instanceof CompetitionListFragment) {
//            popAllStack();
//            addFragment(CategoryFragment.newInstance());
//        }else if(fragment instanceof TweetTagSearchFragment) {
//            popAllStack();
//            addFragment(TweetListFragment.newInstance());
//        }else{
//            popStack();
//        }

        popStack();
    }

    public void popAllStack() {
        FragmentManager fm = this.getSupportFragmentManager();
        for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
            fm.popBackStack();
        }
    }

    public void popStack() {
        getSupportFragmentManager().popBackStack();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void replaceFragment(Fragment fragment, boolean ispopstack) {
        Log.d(TAG, "replaceFragment: " + getSupportFragmentManager().getBackStackEntryCount());
        String backStateName = fragment.getClass().getName();
        String fragmentTag = backStateName;

        FragmentManager manager = this.getSupportFragmentManager();
        boolean fragmentPopped = manager.popBackStackImmediate(backStateName, 0);

        if (!fragmentPopped && manager.findFragmentByTag(fragmentTag) == null) {
            //fragment not in back stack, create it.
            FragmentTransaction ft = manager.beginTransaction();
            ft.replace(R.id.frame_main, fragment, fragmentTag);
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            if (ispopstack)
            ft.addToBackStack(backStateName);
//            ft.commitAllowingStateLoss( );
             ft.commit();
        }
    }

    public void addFragment(Fragment fragment) {
        FragmentManager fragmentManager = this.getSupportFragmentManager();
        FragmentTransaction ft = fragmentManager.beginTransaction();
        ft.add(R.id.frame_main, fragment);
        ft.commit();
    }

    @Override
    public void onClick(View v) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.frame_main);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        switch (v.getId()) {
            case R.id.ll_social:
                isSocial=true;
                // this will clear the back stack and displays no animation on the screen
                fragmentManager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                replaceFragment(HomeFragment.newInstance(), true);
                navigation.setVisibility(View.VISIBLE);
                navigation1.setVisibility(View.GONE);
                SocialView.setVisibility(View.VISIBLE);
                DiatView.setVisibility(View.GONE);
                llSocial.setBackground(getResources().getDrawable(R.drawable.bg_blue_curve));
                llDating.setBackgroundColor(Color.TRANSPARENT);
                tvSocial.setTextColor(getResources().getColor(R.color.white));
                tvDating.setTextColor(getResources().getColor(R.color.colorText_light_gray));
                ivSocial.setImageResource(R.drawable.social_active);
                ivDating.setImageResource(R.drawable.dating_inactive);
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                break;
            case R.id.ll_daiting:
                isSocial =false;
                fragmentManager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                replaceFragment(FriendSuggestion.newInstance(), true);
                navigation.setVisibility(View.GONE);
                navigation1.setVisibility(View.VISIBLE);
                SocialView.setVisibility(View.GONE);
                DiatView.setVisibility(View.VISIBLE);
                llSocial.setBackgroundColor(Color.TRANSPARENT);
                llDating.setBackground(getResources().getDrawable(R.drawable.bg_blue_curve));
                tvSocial.setTextColor(getResources().getColor(R.color.colorText_light_gray));
                tvDating.setTextColor(getResources().getColor(R.color.white));
                ivSocial.setImageResource(R.drawable.social_inactive);
                ivDating.setImageResource(R.drawable.dating_active);
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                break;

            case R.id.tv_home_social:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                tvHomeSocial.setBackgroundColor(getResources().getColor(R.color.color_gray_bg));
                tvChatgroupSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvBookmarkSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvNearfriendSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAddmanagerSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvMypageSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvWalletSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAboutusSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvSecuritySocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvHelpsupportSocial.setBackgroundColor(getResources().getColor(R.color.white));
                popAllStack();
                replaceFragment(HomeFragment.newInstance(), false);
                nvHome.performClick();

                break;
            case R.id.tv_chatgroup_social:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                if (fragment instanceof HomeFragment) {

                } else {
                    replaceFragment(HomeFragment.newInstance(), true);
                }
                tvHomeSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvMypageSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvChatgroupSocial.setBackgroundColor(getResources().getColor(R.color.color_gray_bg));
                tvBookmarkSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvNearfriendSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAddmanagerSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvWalletSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAboutusSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvSecuritySocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvHelpsupportSocial.setBackgroundColor(getResources().getColor(R.color.white));
                CommonUtil.showLongToast(this, "under development");
                break;
            case R.id.tv_bookmark_social:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                if (fragment instanceof HomeFragment) {

                } else {
                    replaceFragment(HomeFragment.newInstance(), true);
                }
                tvHomeSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvMypageSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvChatgroupSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvBookmarkSocial.setBackgroundColor(getResources().getColor(R.color.color_gray_bg));
                tvNearfriendSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAddmanagerSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvWalletSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAboutusSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvSecuritySocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvHelpsupportSocial.setBackgroundColor(getResources().getColor(R.color.white));
//                CommonUtil.showLongToast(this, "under development");
                replaceFragment(BookmarkFragment.newInstance(), true);
                break;
            case R.id.tv_nearfriend_social:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                replaceFragment(FriendsListFragment.newInstance(1), true);

                tvHomeSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvMypageSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvChatgroupSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvBookmarkSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvNearfriendSocial.setBackgroundColor(getResources().getColor(R.color.color_gray_bg));
                tvAddmanagerSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvWalletSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAboutusSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvSecuritySocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvHelpsupportSocial.setBackgroundColor(getResources().getColor(R.color.white));
                break;
            case R.id.tv_addmanager_social:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                replaceFragment(AdsManagerFragment.newInstance(), true);
                tvHomeSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvMypageSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvChatgroupSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvBookmarkSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvNearfriendSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAddmanagerSocial.setBackgroundColor(getResources().getColor(R.color.color_gray_bg));
                tvWalletSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAboutusSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvSecuritySocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvHelpsupportSocial.setBackgroundColor(getResources().getColor(R.color.white));

                break;
            case R.id.tv_mypage_social:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }

                replaceFragment(MyPageFragment.newInstance(), true);

                tvHomeSocial.setBackgroundColor(getResources().getColor(R.color.white));
//                tvHomeSocial.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.home_side),null,null,null);
                tvMypageSocial.setBackgroundColor(getResources().getColor(R.color.color_gray_bg));
//                tvMypageSocial.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.my_pages_side),null,null,null);
                tvChatgroupSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvBookmarkSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvNearfriendSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAddmanagerSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvWalletSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAboutusSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvSecuritySocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvHelpsupportSocial.setBackgroundColor(getResources().getColor(R.color.white));
                break;
            case R.id.tv_wallet_social:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                replaceFragment(WalletFragment.newInstance(), true);
                tvHomeSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvMypageSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvChatgroupSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvBookmarkSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvNearfriendSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAddmanagerSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvWalletSocial.setBackgroundColor(getResources().getColor(R.color.color_gray_bg));
                tvAboutusSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvSecuritySocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvHelpsupportSocial.setBackgroundColor(getResources().getColor(R.color.white));

                break;
            case R.id.tv_aboutus_social:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                CommonUtil.GoToWebViewActivity(this,"https://www.google.com/","About us");
                tvHomeSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvMypageSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvChatgroupSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvBookmarkSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvNearfriendSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAddmanagerSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvWalletSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAboutusSocial.setBackgroundColor(getResources().getColor(R.color.color_gray_bg));
                tvSecuritySocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvHelpsupportSocial.setBackgroundColor(getResources().getColor(R.color.white));
                break;
            case R.id.tv_Security_social:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }

                replaceFragment(SecurityFragment.newInstance(), true);

                tvHomeSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvMypageSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvChatgroupSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvBookmarkSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvNearfriendSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAddmanagerSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvWalletSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAboutusSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvSecuritySocial.setBackgroundColor(getResources().getColor(R.color.color_gray_bg));
                tvHelpsupportSocial.setBackgroundColor(getResources().getColor(R.color.white));
                break;
            case R.id.tv_helpsupport_social:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }

                replaceFragment(ContactUsFragment.newInstance(), true);

                tvHomeSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvMypageSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvChatgroupSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvBookmarkSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvNearfriendSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAddmanagerSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvWalletSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvAboutusSocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvSecuritySocial.setBackgroundColor(getResources().getColor(R.color.white));
                tvHelpsupportSocial.setBackgroundColor(getResources().getColor(R.color.color_gray_bg));
                break;
            case R.id.tv_logout_social:
                confirm();
                break;
            case R.id.tv_global_post:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                toolbar_post.setText("Post");
                replaceFragment(GlobalPostFragment.newInstance(), true);
                break;
            case R.id.tv_home_daiting:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }

                replaceFragment(FriendSuggestion.newInstance(), true);
                break;
            case R.id.tv_aboutus_daiting:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                CommonUtil.GoToWebViewActivity(this,"https://www.google.com/","About us");
                break;
            case R.id.tv_Security_daiting:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                replaceFragment(SecurityFragment.newInstance(), true);
                CommonUtil.showLongToast(this, "under development");
                break;
            case R.id.tv_helpsupport_daiting:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                replaceFragment(ContactUsFragment.newInstance(),true);
                break;
            case R.id.tv_logout_daiting:
                confirm();
                break;
            case R.id.toolbar_menu:
                drawer.openDrawer(GravityCompat.START);
                break;
            case R.id.toolbar_back:
                onBackPressed();
                break;
            case R.id.toolbar_chat:
               Intent intent=new Intent(HomeActivity.this,chatDialogActivity.class);
                //CommonUtil.showLongToast(this, "under development");
              //  Intent intent=new Intent(HomeActivity.this, com.needyyy.app.Chat.groupchatwebrtc.activities.LoginActivity.class);
                intent.putExtra("user","isha2");
               intent.putExtra("password","12345678");
                startActivity(intent);
               // finish();
                break;
            case R.id.toolbar_notification:
                replaceFragment(new com.needyyy.app.notifications.NotificationFragment(), true);
                break;

            case R.id.toolbar_search:
                //replaceFragment(SearchFriendFragment.newInstance());
                //  startActivity(new Intent(this,MainActivity.class));
//                CommonUtil.showLongToast(this, "under development");
                break;
            case R.id.toolbar_filter:
               replaceFragment(FilterFragment.newInstance(),true);
                break;
            case R.id.toolbar_post:
                if(toolbar_post.getText().equals("Post")) {
                    idd=null;
                    if(tv_writesomething.getText().toString().equals("")||tv_writesomething.getText().toString()==null)
                    {
                        Toast.makeText(getApplicationContext(),"Please write post",Toast.LENGTH_SHORT).show();
                    }
                    else {
                        hitGlobalPostApi(String.valueOf(tv_writesomething.getText()));
                    }
                }
                else if(toolbar_post.getText().equals("update"))
                {

                    hitGlobalPostApi(String.valueOf(tv_writesomething.getText()));
                }
                break;
            case R.id.civ_profile_pic:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                replaceFragment(ViewProfileFragment.newInstance(userData.getId(),null),true);
                break;
            case R.id.video_call:

                startOpponentsActivity();

                break;
            case R.id.tv_username:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                }
                replaceFragment(ViewProfileFragment.newInstance(userData.getId(),null),true);
        }
    }

    private void hitGlobalPostApi(String caption) {

            if (CommonUtil.isConnectingToInternet(this)) {
                showProgressDialog();
                WebInterface Service = AppController.getRetrofitInstance().create(WebInterface.class);
                Call<GlobalPost> call =Service.ADDGLOBALPOST(caption,idd);
                call.enqueue(new Callback<GlobalPost>() {
                    @Override
                    public void onResponse(Call<GlobalPost> call, Response<GlobalPost> response) {
                        cancelProgressDialog();
                        GlobalPost globalPost = response.body();
                        if (globalPost.getStatus()) {
                            tv_writesomething.setText("");
                            toolbar_post.setText("Post");
                             Toast.makeText(getApplicationContext(),globalPost.getMessage(),Toast.LENGTH_SHORT).show();
                             getpostData();

                        } else {
                            if (globalPost.getMessage().equals("110110")) {
                                logout();
                            } else {
                                Toast.makeText(getApplicationContext(),globalPost.getMessage(),Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                    @Override
                    public void onFailure(Call<GlobalPost> call, Throwable t) {
                    }
                });
            }
    }
    public void getpostData() {
        if (CommonUtil.isConnectingToInternet(this)) {

            WebInterface Service = AppController.getRetrofitInstance().create(WebInterface.class);
            Call<GlobalPost> call =Service.GLOBALPOST("");
            call.enqueue(new Callback<GlobalPost>() {
                @Override
                public void onResponse(Call<GlobalPost> call, Response<GlobalPost> response) {
                    GlobalPost globalPost = response.body();
                    if (globalPost.getStatus()) {
                        fragment = getSupportFragmentManager().findFragmentById(R.id.frame_main);
                        if(fragment instanceof GlobalPostFragment)
                        {
                            ((GlobalPostFragment) fragment).getUpdatedData(globalPost);
                        }
                    } else {
                        if (globalPost.getMessage().equals("110110")) {
                            logout();

                        } else {

                        }
                    }
                }
                @Override
                public void onFailure(Call<GlobalPost> call, Throwable t) {
                }
            });
        }
    }

    public void logout() {
        AppController.getManager().clearPreference();
        BaseManager.clearPreference();
        generateFirebaseTocken();
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();

    }
    private void generateFirebaseTocken() {
        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            Log.w("SplashActivity", "getInstanceId failed", task.getException());
                            return;
                        }

                        // Get new Instance ID token
                        String token = task.getResult().getToken();
                        Log.e("tocken","====="+token);
                        AppController.getManager().setTocken(token);

                    }
                });
    }

    //logout check
    public  void confirm(){
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
        } else {
            builder = new AlertDialog.Builder(this);
        }
        builder.setTitle("Logout")
                .setMessage("Are you sure you want to Logout?")
                .setPositiveButton("Logout", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        logout();
//                        AppController.getManager().clearPreference();
//                        Intent i = new Intent(this, LoginActivity.class);
//                        startActivity(i);
//                        finish();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.frame_main);

//      if(fragment instanceof QuestionFragment)
        fragment.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (getCurrentFocus() != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
        return super.dispatchTouchEvent(ev);
    }

    /**
     * The name of the function has to be
     * onPaymentSuccess
     * Wrap your code in try catch, as shown, to ensure that this method runs correctly
     */
//    @SuppressWarnings("unused")
    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        try {
            Toast.makeText(this, "Payment Successful: " + razorpayPaymentID, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e("razorPay", "Exception in onPaymentSuccess", e);
        }
    }

    /**
     * The name of the function has to be
     * onPaymentError
     * Wrap your code in try catch, as shown, to ensure that this method runs correctly
     */
//    @SuppressWarnings("unused")
    @Override
    public void onPaymentError(int code, String response) {
        try {
            Toast.makeText(this, "Payment failed: " + code + " " + response, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e("razorpayFailure", "Exception in onPaymentError", e);
        }
    }
    private  void  getpostdata(String taskid) {
        if (CommonUtil.isConnectingToInternet(this)){
            showProgressDialog();
            WebInterface Service = AppController.getRetrofitInstance().create(WebInterface.class);
            Call<Getpostdata> call = Service.getPost(taskid);
            call.enqueue(new Callback<Getpostdata>() {
                @Override
                public void onResponse(Call<Getpostdata> call, Response<Getpostdata> response) {
                    cancelProgressDialog();
                    Getpostdata getpostdata = response.body();
                    postresponse=getpostdata.getData();
                    replaceFragment(ViewFullImageFragment.newInstance(postresponse),false);
                }

                @Override
                public void onFailure(Call<Getpostdata> call, Throwable t) {
                    cancelProgressDialog();

                }
            });
        }else{

        }

    }
    public void setpostbutton(String name,String id)
    {
        toolbar_post.setText(name);
        idd=id;
    }


//    private void getpagedata(String taskid) {
//        if (CommonUtil.isConnectingToInternet(this)){
//            showProgressDialog();
//            WebInterface Service = AppController.getRetrofitInstance().create(WebInterface.class);
//            Call<MyPage> call = Service.getPageDetails(taskid);
//            call.enqueue(new Callback<MyPage>() {
//                @Override
//                public void onResponse(Call<MyPage> call, Response<MyPage> response) {
//                    cancelProgressDialog();
//                    MyPage data = response.body();
//                    PageData pageData= (PageData) data.getData();
//                    replaceFragment(mypage_details.newInstance(pageData),false);
//                }
//
//                @Override
//                public void onFailure(Call<MyPage> call, Throwable t) {
//                    cancelProgressDialog();
//
//                }
//            });
//        }else{
//
//        }
//
//    }

    private void startOpponentsActivity() {
        OpponentsActivity.start(HomeActivity.this, false);
        //finish();
    }
}

