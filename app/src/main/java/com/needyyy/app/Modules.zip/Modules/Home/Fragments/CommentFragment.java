package com.needyyy.app.Modules.Home.Fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.needyyy.AppController;
import com.needyyy.app.Base.BaseFragment;
import com.needyyy.app.Base.CommonPojo;
import com.needyyy.app.Modules.Home.Activities.HomeActivity;
import com.needyyy.app.Modules.Home.Adapters.CommentAdapter;
import com.needyyy.app.Modules.Home.callback.CommentCallback;
import com.needyyy.app.Modules.Home.modle.CommentBase;
import com.needyyy.app.Modules.Home.modle.CommentData;
import com.needyyy.app.Modules.Login.model.register.UserDataResult;
import com.needyyy.app.R;
import com.needyyy.app.manager.BaseManager.BaseManager;
import com.needyyy.app.utils.CommonUtil;
import com.needyyy.app.utils.Constant;
import com.needyyy.app.views.AppTextView;
import com.needyyy.app.webutils.WebInterface;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.needyyy.app.constants.Constants.kCurrentUser;

public class CommentFragment extends BaseFragment implements View.OnClickListener , CommentCallback {
    private RecyclerView rvComments;
    private LinearLayoutManager linearLayoutManager ;
    private CommentAdapter commentAdapter ;
    private ArrayList<CommentData> commentDataList ;
    private AppTextView tvComment;
    private String postId ,commentId = "0",PostUserid;
    private EditText etComment;
    private CommentCallback commentCallback ;
    private CircleImageView circleImageProfile ;
    UserDataResult userData ;
    public static CommentFragment newInstance(String id,String PostUserid) {
        CommentFragment fragment = new CommentFragment();
        Bundle args = new Bundle();
        args.putString(Constant.POST_ID,id);
        args.putString(Constant.POSTUSERID,PostUserid);
        fragment.setArguments(args);
        return fragment;
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState, R.layout.fragment_comment);
        if (getArguments() != null) {
            postId     = getArguments().getString(Constant.POST_ID);
            PostUserid =getArguments().getString(Constant.POSTUSERID);
        }
    }

    @Override
    protected void initView(View mView) {
        rvComments         = mView.findViewById(R.id.rv_comment);
        tvComment          = mView.findViewById(R.id.tv_comment);
        etComment          = mView.findViewById(R.id.et_comment);
        circleImageProfile = mView.findViewById(R.id.img_profile);
        commentDataList = new ArrayList<>();
         userData = (BaseManager.getDataFromPreferences(kCurrentUser, UserDataResult.class));

    }

    @Override
    protected void bindControls(Bundle savedInstanceState) {
        ((HomeActivity)getActivity()).manageToolbar(getContext().getResources().getString(R.string.comments), "");
        tvComment.setOnClickListener(this);
        getCommentApi();
        commentAdapter = new CommentAdapter(1,getActivity(),commentDataList ,this,PostUserid);
        linearLayoutManager = new LinearLayoutManager(getContext());
        rvComments.setLayoutManager(linearLayoutManager);
        rvComments.setAdapter(commentAdapter);
        if (!TextUtils.isEmpty(userData.getProfilePicture())) {
            Glide.with(getActivity())
                    .load(userData.getProfilePicture())
                    .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.NONE).placeholder(R.drawable.needyy).error(R.drawable.needyy))
                    .into(circleImageProfile);
        } else {
            circleImageProfile.setImageResource(R.drawable.needyy);
        }

    }

    private void getCommentApi() {
        if (CommonUtil.isConnectingToInternet(getActivity())){
            showProgressDialog();
            WebInterface Service = AppController.getRetrofitInstance().create(WebInterface.class);
            Call<CommentBase> call = Service.getComment(postId,commentId,"20","1");
            call.enqueue(new Callback<CommentBase>() {
                @Override
                public void onResponse(Call<CommentBase> call, Response<CommentBase> response) {
                    cancelProgressDialog();
                    Log.e("dssfsfssf", "fsfsfs" + response.body().toString());
                    CommentBase commentBase = response.body();
                    if (commentBase.getStatus()) {
                        if (commentDataList!= null && commentDataList.size()!=0){
                            commentDataList.clear();
                        }
                        commentDataList.addAll(commentBase.getData());
                        commentAdapter.notifyDataSetChanged();
                    } else {
                        if (commentBase.getMessage().equals("110110")){
                            ((HomeActivity)getActivity()).logout();

                        }else{
                            snackBar(commentBase.getMessage());
                        }
                    }
                }

                @Override
                public void onFailure(Call<CommentBase> call, Throwable t) {
                    cancelProgressDialog();
                    snackBar(t.getMessage());
                }
            });

        }
        else{

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tv_comment:
                if (etComment.getText().toString().length()!=0){
                    postComment(etComment.getText().toString(), "0");
                }else{
                    snackBar("comment field cant empty");
                }

                break;
        }
    }
    public void postComment(String comment, String cpmmentId){
        WebInterface Service = AppController.getRetrofitInstance().create(WebInterface.class);
        Call<CommonPojo> call = Service.postComment(postId, comment,cpmmentId);
        call.enqueue(new Callback<CommonPojo>() {
            @Override
            public void onResponse(Call<CommonPojo> call, Response<CommonPojo> response) {

                Log.e("dssfsfssf", "fsfsfs" + response.body().toString());
                CommonPojo acceptRejectRequest = response.body();
                if (acceptRejectRequest.getStatus()) {
                    etComment.setText("");
                    getCommentApi();
                } else {
                    if (acceptRejectRequest.getMessage().equals("110110")){
                        ((HomeActivity)getActivity()).logout();

                    }else{
                        ((HomeActivity)getActivity()).snackBar(acceptRejectRequest.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<CommonPojo> call, Throwable t) {
                //  cancelProgressDialog();
            }
        });

    }

    @Override
    public void postComments(String Comment, String cpmmentId) {
        ((HomeActivity)getActivity()).replaceFragment(CommentReplyFragment.newInstance(postId,cpmmentId,PostUserid), true);
    }
}
