package com.needyyy.app.Modules.Profile.fragments;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import com.needyyy.AppController;
import com.needyyy.app.Base.BaseFragment;
import com.needyyy.app.Modules.Home.Activities.HomeActivity;
import com.needyyy.app.Modules.Profile.adapters.SeeAllPhotoAdapter;
import com.needyyy.app.Modules.Profile.models.UserPicture.Datum;
import com.needyyy.app.Modules.Profile.models.UserPicture.GetUserPictures;
import com.needyyy.app.R;
import com.needyyy.app.webutils.WebInterface;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SeeAllPhotoFragment extends BaseFragment  {
    SeeAllPhotoAdapter seeAllPhotoAdapter;
    String memberId="";
    RecyclerView recyclerView;
    private ArrayList<Datum> getUserPicturesArrayList = new ArrayList<com.needyyy.app.Modules.Profile.models.UserPicture.Datum>() ;

    public SeeAllPhotoFragment() {
    }

    public static Fragment newInstance() {
        SeeAllPhotoFragment seeAllPhotoFragment=new SeeAllPhotoFragment();
        return seeAllPhotoFragment;
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        if(getActivity() instanceof HomeActivity)
        {
            ((HomeActivity) getActivity()).manageToolbar("All Photos","1");
        }
        getUserPicture();
        super.onCreate(savedInstanceState,R.layout.fragment_see_all_photo);
    }
    @Override
    protected void initView(View mView) {
        recyclerView = mView.findViewById(R.id.recycler_view);
    }

    @Override
    protected void bindControls(Bundle savedInstanceState) {
        if(getUserPicturesArrayList.size()!=0) {
            setPicture();
        }
    }

    private class GridSpacingItemDecoration extends RecyclerView.ItemDecoration {
        public GridSpacingItemDecoration(int i, int i1, boolean b) {
        }
    }

    private void getUserPicture() {
        showProgressDialog();
        WebInterface Service = AppController.getRetrofitInstance().create(WebInterface.class);
        Call<GetUserPictures> call = Service.getUserPictures(1,20,memberId);
        call.enqueue(new Callback<GetUserPictures>() {
            @Override
            public void onResponse(Call<GetUserPictures> call, Response<GetUserPictures> response) {
                cancelProgressDialog();
                Log.e("dssfsfssf", "fsfsfs" + response.body().toString());
                GetUserPictures getUserPictures = response.body();
                if (getUserPictures.getStatus()) {
                    if (getUserPicturesArrayList!=null || getUserPicturesArrayList.size()==0){
                        getUserPicturesArrayList.clear();
                    }
                    for(int i=0;i<getUserPictures.getData().size();i++)
                    {
                        getUserPicturesArrayList.add(getUserPictures.getData().get(i));
                    }

                } else {
                    if (getUserPictures.getMessage().equals("110110")){
                        ((HomeActivity)getActivity()).logout();

                    } else {
                        snackBar(getUserPictures.getMessage());
                    }
                }

                setPicture();

            }
            @Override
            public void onFailure(Call<GetUserPictures> call, Throwable t) {
                cancelProgressDialog();
                snackBar(t.getMessage());
            }
        });
    }
    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    public  void setPicture(){
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 3);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.addItemDecoration(new com.needyyy.app.views.GridSpacingItemDecoration(3, 18, true));
        seeAllPhotoAdapter = new SeeAllPhotoAdapter(getContext(),getUserPicturesArrayList);
        recyclerView.setAdapter(seeAllPhotoAdapter);
    }
}
