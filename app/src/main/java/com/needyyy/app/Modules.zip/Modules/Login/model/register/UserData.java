package com.needyyy.app.Modules.Login.model.register;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class UserData {

}
