package com.needyyy.app.Modules.Knocks.fragment;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import com.needyyy.app.R;
import com.needyyy.AppController;
import com.needyyy.app.Base.BaseFragment;
import com.needyyy.app.Modules.Home.Activities.HomeActivity;
import com.needyyy.app.Modules.Home.Adapters.KnockRequestAdapter;
import com.needyyy.app.Modules.Knocks.models.GetReceivedRequest;
import com.needyyy.app.Modules.Knocks.models.ReceivedData;
import com.needyyy.app.views.AppTextView;
import com.needyyy.app.webutils.WebInterface;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GetKnocksFriend extends BaseFragment implements View.OnClickListener  {

    private RecyclerView rvKnockrequest;
    private ArrayList<ReceivedData> arrGetRequests = new ArrayList<>();
    private KnockRequestAdapter knockRequestAdapter ;
    AppTextView atvKnockText;
    TextView tvNoResult;

    public static GetKnocksFriend newInstance() {
        GetKnocksFriend getKnocksFriend = new GetKnocksFriend();
        Bundle args = new Bundle();
        getKnocksFriend.setArguments(args);
        return getKnocksFriend;
    }


    @Override
    public void onClick(View v) {

    }

    @Override
    protected void initView(View mView) {
        rvKnockrequest = mView.findViewById(R.id.rv_knock_request);
        tvNoResult     = mView.findViewById(R.id.tv_no_result);

        ((HomeActivity)getActivity()).manageToolbar("Knock", "");
    }
    @SuppressLint("MissingSuperCall")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState, R.layout.fragment_get_knocks_friend);

    }


    @Override
    protected void bindControls(Bundle savedInstanceState) {
        tvNoResult.setVisibility(View.GONE);
        getRequestList();
        setKnockFriendAdapter();
    }
    private void setKnockFriendAdapter() {
        knockRequestAdapter = new KnockRequestAdapter(getActivity(),arrGetRequests,5);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        rvKnockrequest.setLayoutManager(layoutManager);
        rvKnockrequest.setAdapter(knockRequestAdapter);

//        rvKnockrequest.setHasFixedSize(true);
//        RecyclerView.ItemDecoration dividerItemDecoration = new DividerItemRecyclerDecoration(getContext(), R.drawable.canvas_recycler_divider);
//        rvKnockrequest.addItemDecoration(dividerItemDecoration);
    }

    public void getRequestList() {
//        showProgressDialog();
        WebInterface Service = AppController.getRetrofitInstance().create(WebInterface.class);
        Call<GetReceivedRequest> call = Service.GetFriends("20", "1");
        call.enqueue(new Callback<GetReceivedRequest>() {
            @Override
            public void onResponse(Call<GetReceivedRequest> call, Response<GetReceivedRequest> response) {
//                cancelProgressDialog();
                Log.e("dssfsfssf", "fsfsfs" + response.body().toString());
                GetReceivedRequest getReceivedRequest = response.body();
                if (getReceivedRequest.getStatus()) {
                    arrGetRequests.clear();
                    arrGetRequests.addAll(getReceivedRequest.getData());
                    knockRequestAdapter.notifyDataSetChanged();
//                        snackBar(getReceivedRequest.getMessage());
                } else {
                    tvNoResult.setVisibility(View.VISIBLE);
                    if (getReceivedRequest.getMessage().equals("110110")) {
                        ((HomeActivity) getActivity()).logout();

                    } else {
                        snackBar(getReceivedRequest.getMessage());
                    }
                }
            }
            @Override
            public void onFailure(Call<GetReceivedRequest> call, Throwable t) {
                cancelProgressDialog();
                snackBar(t.getMessage());
            }
        });
    }
}
