package com.needyyy.app.Modules.Home.callback;

public interface CommentCallback {
    public void postComments(String Comment, String cpmmentId);
}
