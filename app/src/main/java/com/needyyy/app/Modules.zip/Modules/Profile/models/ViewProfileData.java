package com.needyyy.app.Modules.Profile.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.needyyy.app.Modules.AddPost.models.People;
import com.needyyy.app.Modules.Profile.models.UserPicture.ProfessionDetails;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ViewProfileData implements Serializable {


    @SerializedName("cover_picture")
    @Expose
    private String coverpicture;
    @SerializedName("profile_picture")
    @Expose
    private String profilePicture;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("ssn")
    @Expose
    private String ssn;
    @SerializedName("bio")
    @Expose
    private String bio;
    @SerializedName("dob")
    @Expose
    private String dob;
    @SerializedName("status")
    @Expose
    private String status;

    public String getIsfriend() {
        return isfriend;
    }

    public void setIsfriend(String isfriend) {
        this.isfriend = isfriend;
    }

    @SerializedName("is_friend")
    @Expose
    private String isfriend;

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    @SerializedName("nick_name")
    @Expose
    private String nickname;

    public void setProfessionDetails(ArrayList<ProfessionDetails> professionDetails) {
        this.professionDetails = professionDetails;
    }

    public ArrayList<ProfessionDetails> getProfessionDetails() {
        return professionDetails;
    }

    @SerializedName("profession_detail")
    @Expose
    private ArrayList<ProfessionDetails> professionDetails = null;

    @SerializedName("user_address")
    @Expose
    private List<LocationDetailPojo> userAddress = null;


    @SerializedName("photos")
    @Expose
    private List<Photo> photos = null;
    @SerializedName("friends")
    @Expose
    private List<People> friends = null;

    public String getProfilePicture() {
        return profilePicture;
    }

    public void setProfilePicture(String profilePicture) {
        this.profilePicture = profilePicture;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getDob() {
        return dob;
    }
    public void setCoverpicture(String coverpicture) {
        this.coverpicture = coverpicture;
    }

    public String getCoverpicture() {
        return coverpicture;
    }
    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<LocationDetailPojo> getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(List<LocationDetailPojo> userAddress) {
        this.userAddress = userAddress;
    }

    public List<Photo> getPhotos() {
        return photos;
    }

    public void setPhotos(List<Photo> photos) {
        this.photos = photos;
    }

    public List<People> getFriends() {
        return friends;
    }

    public void setFriends(List<People> friends) {
        this.friends = friends;
    }


}
