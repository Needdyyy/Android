package com.needyyy.app.Modules.Dating.suggestions.adapter;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.needyyy.app.Modules.AddPost.models.People;
import com.needyyy.app.Modules.Dating.BlurTransformation;
import com.needyyy.app.Modules.Dating.DatingActivity;
import com.needyyy.app.Modules.Dating.suggestions.fragment.SendRequestFragment;
import com.needyyy.app.Modules.Home.Activities.HomeActivity;
import com.needyyy.app.R;
import java.util.ArrayList;
import static com.bumptech.glide.request.RequestOptions.bitmapTransform;

public class SuggestionAdapter extends RecyclerView.Adapter<SuggestionAdapter.modelViewHolder>{
    private Context context;
    ArrayList<People> arrfriends = new ArrayList<>();

    public SuggestionAdapter(Context context, ArrayList<People> arrfriends ) {
        this.context = context;
        this.arrfriends = arrfriends;
    }

    @NonNull
    @Override
    public SuggestionAdapter.modelViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater=LayoutInflater.from(viewGroup.getContext());
        View view=inflater.inflate(R.layout.list_item,viewGroup,false);
        return new SuggestionAdapter.modelViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SuggestionAdapter.modelViewHolder modelViewHolder, int position) {
        if (arrfriends.size() != 0) {
            People people = arrfriends.get(position);
            String s = people.getSsn().substring(0, 2);
            for (int i = s.length(); i <people.getSsn().length() ; i++) {
                s=s+"*";
            }
            modelViewHolder.btnssn.setText(s);
            if (!people.getProfilePicture().isEmpty()) {
                Glide.with(context).load(people.getProfilePicture())
                        .apply(bitmapTransform(new BlurTransformation(context)))
                        .into(modelViewHolder.imageView);
            } else {
                Glide.with(context).load(context.getDrawable(R.drawable.xx))
                        .apply(bitmapTransform(new BlurTransformation(context)))
                        .into(modelViewHolder.imageView);
            }
            // CommonUtil.ConvertURLToBitmap(people.getProfilePicture(),context ,modelViewHolder.imageView);

            modelViewHolder.cvSuggestion.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((HomeActivity) context).replaceFragment(SendRequestFragment.newInstance(people), true);
                }
            });
        }
        else
        {
            Toast.makeText(context,"Friends not found",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public int getItemCount() {
        return arrfriends.size();
    }

    public class modelViewHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        Button btnssn;
        RatingBar ratingBar;
        CardView cvSuggestion;

        public modelViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView=itemView.findViewById(R.id.circuler_profile_image);
            btnssn =itemView.findViewById(R.id.name);
            ratingBar=itemView.findViewById(R.id.ratingBar);
            cvSuggestion = itemView.findViewById(R.id.card_view);
        }
    }
}
