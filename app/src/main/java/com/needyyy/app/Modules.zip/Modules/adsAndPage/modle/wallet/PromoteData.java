package com.needyyy.app.Modules.adsAndPage.modle.wallet;

public class PromoteData {
}
