package com.needyyy.app.Modules.Home.Fragments;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.needyyy.app.ImageClasses.ZoomImage.ZoomImage;
import com.needyyy.app.Modules.Home.Activities.HomeActivity;
import com.needyyy.app.Modules.Home.modle.PostResponse;
import com.needyyy.app.vedio.Vedio;
import com.squareup.picasso.Picasso;
import com.needyyy.app.R;
import java.util.ArrayList;

/**
 * Created by Admin on 16-07-2019.
 */

class imageslider extends PagerAdapter {
    //private ArrayList<Products> product;
    private LayoutInflater inflater;
    private PostResponse postResponse;
   // private ArrayList<Stocks> stocks=new ArrayList<>();
    private Context context;
    public imageslider(Context context,PostResponse postResponse) {
        this.postResponse=postResponse;
        inflater = LayoutInflater.from(context);
        this.context=context;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
        return postResponse.getPostMeta().size();
    }

    @Override
    public Object instantiateItem(ViewGroup view, int position) {
        View imageLayout = inflater.inflate(R.layout.imageslider, view, false);
        assert imageLayout != null;
        final ImageView imageView = (ImageView) imageLayout
                .findViewById(R.id.image);
           Glide.with(context)
                .load(postResponse.getPostMeta().get(position).getLink().toString())
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.NONE).placeholder(R.drawable.needyy).error(R.drawable.needyy))
                .into(imageView);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(context instanceof HomeActivity) {
                    if (postResponse.getPostMeta().get(position).getFileType().equals("image")) {
                        ((HomeActivity) context).replaceFragment(ZoomImage.newInstance(postResponse.getPostMeta().get(position).getLink().toString()), true);
                    }
                    else if (postResponse.getPostMeta().get(position).getFileType().equals("youtube"))
                    {
                        Intent intent=new Intent(context,Vedio.class);
                        intent.putExtra("vedio_id",postResponse.getPostMeta().get(position).getFilelink());
                        context.startActivity(intent);
                    }
                }
            }
        });

        view.addView(imageLayout, 0);
        return imageLayout;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view.equals(object);
    }

    @Override
    public void restoreState(Parcelable state, ClassLoader loader) {
    }

    @Override
    public Parcelable saveState() {

        return null;
    }
}
