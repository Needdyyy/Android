package com.needyyy.app.Modules.Home.Fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import com.needyyy.AppController;
import com.needyyy.app.Base.BaseFragment;
import com.needyyy.app.Modules.AddPost.models.AddPost.TaggedPerson;
import com.needyyy.app.Modules.Home.Activities.HomeActivity;
import com.needyyy.app.Modules.Home.Adapters.UserListAdapter;
import com.needyyy.app.Modules.Home.modle.UserListBase;
import com.needyyy.app.R;
import com.needyyy.app.utils.Constant;
import com.needyyy.app.webutils.WebInterface;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserListFragment extends BaseFragment implements View.OnClickListener {
    private RecyclerView rvPeople;
    private LinearLayoutManager linearLayoutManager ;
    private UserListAdapter userListAdapter ;
    private String postId ;
    private List<TaggedPerson> userDataList ;

    public static UserListFragment newInstance(String id) {
        UserListFragment fragment = new UserListFragment();
        Bundle args = new Bundle();
        args.putString(Constant.POST_ID,id);
        fragment.setArguments(args);
        return fragment;
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState, R.layout.fragment_userlist);
        if (getArguments() != null) {
            postId = getArguments().getString(Constant.POST_ID);
        }

    }

    @Override
    protected void initView(View mView) {
        rvPeople  = mView.findViewById(R.id.rv_people);
        userDataList = new ArrayList<>();
    }

    @Override
    protected void bindControls(Bundle savedInstanceState) {
        ((HomeActivity)getActivity()).manageToolbar(getContext().getResources().getString(R.string.likes), "");


        userListAdapter = new UserListAdapter(1,getActivity(), (ArrayList<TaggedPerson>) userDataList);
        linearLayoutManager = new LinearLayoutManager(getContext());
        rvPeople.setLayoutManager(linearLayoutManager);
        rvPeople.setAdapter(userListAdapter);
        LikedUserList();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tv_comment:

                break;
        }
    }
    private void LikedUserList() {
        ((HomeActivity)getActivity()).showProgressDialog();
        WebInterface Service = AppController.getRetrofitInstance().create(WebInterface.class);
        Call<UserListBase> call = Service.likePostUserList(postId,1,30);
        call.enqueue(new Callback<UserListBase>() {
            @Override
            public void onResponse(Call<UserListBase> call, Response<UserListBase> response) {
                ((HomeActivity)getActivity()).cancelProgressDialog();
                Log.e("dssfsfssf", "fsfsfs" + response.body().toString());
                UserListBase userlistData = response.body();
                if (userlistData.getStatus()) {
                    if (userlistData!=null && userDataList.size()!=0){
                        userDataList.clear();
                    }
                    userDataList.addAll(userlistData.getData());
                    userListAdapter.notifyDataSetChanged();
                } else {
                    if (userlistData.getMessage().equals("110110")){
                        ((HomeActivity)getActivity()).logout();

                    }else{
                        snackBar(userlistData.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<UserListBase> call, Throwable t) {
                ((HomeActivity)getActivity()).cancelProgressDialog();
                snackBar(t.getMessage());
            }
        });

    }

}
