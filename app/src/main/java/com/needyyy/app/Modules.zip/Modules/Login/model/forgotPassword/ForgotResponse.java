
package com.needyyy.app.Modules.Login.model.forgotPassword;


public class ForgotResponse {


}
