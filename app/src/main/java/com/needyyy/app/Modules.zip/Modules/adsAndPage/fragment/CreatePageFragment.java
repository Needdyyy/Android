package com.needyyy.app.Modules.adsAndPage.fragment;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.needyyy.app.Base.BaseFragment;
import com.needyyy.app.Modules.Home.Activities.HomeActivity;
import com.needyyy.app.R;
import com.needyyy.app.utils.CommonUtil;
import com.needyyy.app.utils.Constant;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;


import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.CAMERA;
import static android.app.Activity.RESULT_OK;
import static com.needyyy.app.ImageClasses.TakeImageClass.REQUEST_CODE_GALLERY;
import static com.needyyy.app.ImageClasses.TakeImageClass.REQUEST_CODE_TAKE_PICTURE;

public class CreatePageFragment extends BaseFragment implements View.OnClickListener{

    private ImageView imgBanner;
    private ImageView imgPage;
    private TextInputEditText etTitle,etDescription ;
    private TextView btnNext;
    private int mediaType;
    String banerImageUrl="",profileImageurl="";
    private Uri bannerUri,profileUri;
    private ArrayList<Uri> imagelist = new ArrayList<>();
    private static final int PERMISSION_REQUEST_CODE = 200;
    private static final String TAG = "PostFragment";
    String[] permissions = new String[]{
            Manifest.permission.CAMERA,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
    };

    public CreatePageFragment() {
        // Required empty public constructor
    }


    public static CreatePageFragment newInstance() {
        CreatePageFragment fragment = new CreatePageFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState, R.layout.fragment_create_page);
        if (getArguments() != null) {

        }
    }

    @Override
    protected void initView(View mView) {
        imgBanner     = mView.findViewById(R.id.img_page_banner);
        imgPage       = mView.findViewById(R.id.img_add_pagephoto);
        etTitle       = mView.findViewById(R.id.et_page_title);
        etDescription = mView.findViewById(R.id.et_page_description);
        btnNext       = mView.findViewById(R.id.btn_next);
    }

    @Override
    protected void bindControls(Bundle savedInstanceState) {
        btnNext.setOnClickListener(this);
        imgBanner.setOnClickListener(this);
        imgPage.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.img_page_banner:
                mediaType =1;
                permissionCheck();
                break;
            case R.id.img_add_pagephoto:
                mediaType= 2;
                permissionCheck();
                break;
            case R.id.btn_next :
                checkValidation();
                break;

        }
    }
    private void checkValidation() {
        if (bannerUri!=null){
            if (profileUri!=null){
                if (!etTitle.getText().toString().isEmpty()){
                    if (!etDescription.getText().toString().isEmpty()){
                        imagelist.add(0,bannerUri);
                        imagelist.add(1,profileUri);
                        ((HomeActivity)getActivity()).replaceFragment(PageCategoryFragment.newInstance(imagelist,etTitle.getText().toString().trim(),etDescription.getText().toString().trim()), true);
                        etTitle.setText("");
                        etDescription.setText("");
                    }else{
                        snackBar(getContext().getResources().getString(R.string.descriptionmsg));
                    }
                }else{
                    snackBar(getContext().getResources().getString(R.string.titlemsg));
                }
            }else{
                snackBar(getContext().getResources().getString(R.string.bannerprofilemsg));
            }
        }else{
            snackBar(getContext().getResources().getString(R.string.bannerimgmsg));
        }

    }

    public void permissionCheck() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkPermissions(getActivity(), permissions)) {

                onPickImage();

//                Snackbar.make(view, "Permission already granted.", Snackbar.LENGTH_LONG).show();
//            }else {
////                Snackbar.make(view, "Please request permission.", Snackbar.LENGTH_LONG).show();
//                requestPermission();
            }
        } else {

            onPickImage();


        }
    }
    public void onPickImage() {
        getImagePickerDialog(getActivity(), "Select Option");
    }
    public void getImagePickerDialog(final Activity ctx, final String title) {
        AlertDialog.Builder alertBuild = new AlertDialog.Builder(ctx);

        alertBuild
                .setTitle(title)
                .setCancelable(true)
                .setPositiveButton("Camera", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();
                        getImageFromCamera();
                    }
                })
                .setNegativeButton("Gallery", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();
                        getImageFromGallery();
                    }
                });
        AlertDialog dialog = alertBuild.create();
        dialog.show();
        int alertTitle = ctx.getResources().getIdentifier("alertTitle", "id", "android");
        ((TextView) dialog.findViewById(alertTitle)).setGravity(Gravity.CENTER);
        ((TextView) dialog.findViewById(alertTitle)).setGravity(Gravity.CENTER);
    }
    /**
     * get image from camera
     */
    private void getImageFromCamera() {
        checkStorage();
        try {
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, newProfileImageUri);
            cameraIntent.putExtra("return-data", true);
            startActivityForResult(cameraIntent, REQUEST_CODE_TAKE_PICTURE);
        } catch (Exception e) {
            Toast.makeText(getActivity(), "" + e.getMessage(), Toast.LENGTH_SHORT).show();
            Log.d("Error", e.toString());
        }
    }

    /**
     * get image from camera or gallery
     */
    private void getImageFromGallery() {
        try {
            Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
            photoPickerIntent.setType("image/*");
            photoPickerIntent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(photoPickerIntent, REQUEST_CODE_GALLERY);
        } catch (Exception e) {
            Toast.makeText(getActivity(), "" + e.getMessage(), Toast.LENGTH_SHORT).show();
            Log.d("Error", e.toString());
        }
    }


    /**
     * call this function to create image name and its uri
     */
    private File newFile;
    private Uri newProfileImageUri;
    private String state, imageName;

    public void checkStorage(){
        imageName = "";
        state = Environment.getExternalStorageState();

        imageName = Constant.PARENT_FOLDER+"_"+ String.valueOf(System.nanoTime()) + ".png";

        if (Environment.MEDIA_MOUNTED.equals(state)) {
            newFile = new File(Environment.getExternalStorageDirectory(), imageName);
            newProfileImageUri = Uri.fromFile(newFile);
        } else {
            newFile = new File(getActivity().getFilesDir(), imageName);
            newProfileImageUri = Uri.fromFile(newFile);
        }
        Log.e("createVideofile","newProfileImageUri"+newProfileImageUri);
        // Log.e("createVideofile","imageName"+imageName);
    }
    private void requestPermission() {

        ActivityCompat.requestPermissions(getActivity(), new String[]{ACCESS_FINE_LOCATION, CAMERA}, PERMISSION_REQUEST_CODE);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        Log.d(TAG, "Permission callback called-------");
        switch (requestCode) {
            case REQUEST_ID_MULTIPLE_PERMISSIONS: {

                ArrayList<String> _arPermission = new ArrayList<String>();
                if (grantResults.length > 0) {
                    Log.d(TAG, "length" + permissions.length);
                    for (int i = 0; i < permissions.length; i++) {
                        Log.d(TAG, "lengthch" + permissions[i] + " " + grantResults[i]);
                        if (grantResults[i] != 0) {
                            _arPermission.add("" + grantResults[i]);
                        }
                    }

                    if (_arPermission.size() == 0) {

                        onPickImage();

                    } else {
                        Log.d(TAG, "Some permissions are not granted ask again ");
                        CommonUtil.showAlert(getActivity(), "These Permissions required for this app.Go to settings and enable permissions.", "Permissions");
                    }
                }
            }
        }
    }

    /**
     *  get selected file in onActivityResult
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_GALLERY && resultCode == RESULT_OK && null != data) {

            try {
                // When an Image is picked
                if (requestCode == REQUEST_CODE_GALLERY && resultCode == RESULT_OK
                        && null != data) {

                    // Get the Image from data
                    if(data.getData()!=null) {
                        InputStream inputStream = getActivity().getContentResolver().openInputStream(data.getData());
                        checkStorage();
                        FileOutputStream fileOutputStream = new FileOutputStream(newFile);
                        CommonUtil.copyStream(inputStream, fileOutputStream);
                        fileOutputStream.close();
                        inputStream.close();
//                        if (mediaType == 1){
//                            imgBanner.setImageURI(newProfileImageUri);
//                        }else if(mediaType == 2){
//                            imgPage.setImageURI(newProfileImageUri);
//                        }
                        if (mediaType ==1){
                            bannerUri = newProfileImageUri ;
                            imgBanner.setImageURI(newProfileImageUri);
                        }else if(mediaType ==2){
                            imgPage.setImageURI(newProfileImageUri);
                            profileUri = newProfileImageUri ;
                        }


                    }
                    else {
                        Toast.makeText(getActivity(), "You haven't picked any Media",
                                Toast.LENGTH_LONG).show();
                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Toast.makeText(getActivity(), "Something went wrong, Try again...", Toast.LENGTH_LONG).show();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        else if (requestCode == REQUEST_CODE_TAKE_PICTURE && resultCode == RESULT_OK) {
            if (newProfileImageUri!=null){
                if (mediaType ==1){
                    bannerUri = newProfileImageUri ;
                    imgBanner.setImageURI(newProfileImageUri);
                }else if(mediaType ==2){
                    imgPage.setImageURI(newProfileImageUri);
                    profileUri = newProfileImageUri ;
                }


            }

        }
    }

}
